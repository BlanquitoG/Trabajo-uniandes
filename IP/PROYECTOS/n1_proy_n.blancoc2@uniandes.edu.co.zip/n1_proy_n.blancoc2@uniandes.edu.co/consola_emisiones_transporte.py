# -*- coding: utf-8 -*-
"""
Created on Thu Aug 20 15:57:04 2026

@author: blanc
"""

import cupiambiente as ca

def ejecutar_emisiones_transporte():
    
    recorrido_dia = float(input("Ingrese su recorrio al dia en Km: "))
    
    medio = float(input("Inrese el valor asignado a su medio, recuerde que para"\
                        "automovil es de 0.184, el de autobus de  0.05 y el de bicicleta/caminando 0: "))
    resultado = ca.calcular_emisiones_transporte(recorrido_dia, medio)
    print("usted contamino", resultado, "KgCo2/km hoy")                    

ejecutar_emisiones_transporte()