# -*- coding: utf-8 -*-
"""
Created on Fri Aug 21 11:21:51 2026

@author: blanc
"""

import cupiambiente as ca

def contaminacion():
    kg_carne_fria = float(input("Ingrese la cantidad de carne consumida  en kg:"))
    
    total = float(input("Ingrese la cantidad de carne consumida al mes en kg:"))
    
    vairedad_xd = int(input("ingrese la cantidad diferente de carne que consumes:"))
    
    resultado = ca.calcular_emisiones_alimentacion(kg_carne_fria, total, vairedad_xd)
    print("Usted contamino", resultado, "kgCo2/kgcomida")

contaminacion()