# -*- coding: utf-8 -*-
"""
Created on Thu Aug 20 16:21:00 2026

@author: blanc
"""

import cupiambiente as ca

def calcular_elec():
    
    energia = float(input("Ingrese la cantidad de kwh del mes: "))
    
    perdida_re = float(input("Ingrese la perdida de red ( 0.0-0.5): "))
    
    resultado = ca.calcular_emisiones_electricidad(energia,perdida_re)
    print("Usted consumio", resultado, "KCO2/kWh este mes")
    
calcular_elec()    