# -*- coding: utf-8 -*-
"""
Created on Fri Aug 21 11:56:25 2026

@author: blanc
"""

import cupiambiente as ca

def arb():
    recorrido_dia = float(input("Ingrese su recorrio al dia en Km: "))
    
    medio = float(input("Inrese el valor asignado a su medio, recuerde que para"\
                        "automovil es de 0.184, el de autobus de  0.05 y el de bicicleta/caminando 0: "))
    energia = float(input("Ingrese la cantidad de kwh del mes: "))
        
    perdida_re = float(input("Ingrese la perdida de red ( 0.0-0.5): "))
    
    kg_carne_fria = float(input("Ingrese la cantidad de carne consumida  en kg:"))
    
    total = float(input("Ingrese la cantidad de carne consumida al mes en kg:"))
  
    vairedad_xd = int(input("ingrese la cantidad diferente de carne que consumes:"))

    
    emi = ca.calcular_arboles_necesarios(recorrido_dia, medio, energia, perdida_re, kg_carne_fria, total, vairedad_xd) 
    
    print('Se necesitan,', emi, 'arboles para descontaminar tu contaminacion')

arb()