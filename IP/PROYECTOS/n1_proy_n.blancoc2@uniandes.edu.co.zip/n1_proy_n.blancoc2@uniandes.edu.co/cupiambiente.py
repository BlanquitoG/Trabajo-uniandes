    # -*- coding: utf-8 -*-
"""
Created on Wed Aug 19 11:24:47 2026

@author: blanc
"""
def calcular_emisiones_transporte(km_dia: float, factor_emision_km: float)-> float:
    '''
    SUMMARY.

    Parameters
    ----------
    km_dia : float
        DESCRIPTION.
    factor_emision_km : float
        DESCRIPTION.

    Returns
    -------
    float
        DESCRIPTION.
        emisiones diarias de una persona por concepto de transporte.
    '''
    
    respuesta = round(km_dia * factor_emision_km,2)
    
    
    
    
    
    
    return respuesta
    

def calcular_emisiones_electricidad (kwh: float, perdida_red: float) -> float:
    '''
    SUMMARY.

    Parameters
    ----------
    kwh : float
        DESCRIPTION.
    perdida_red : float
        DESCRIPTION.

    Returns
    -------
    float
        DESCRIPTION.
        Emisiones mensuales de una persona por concepto de electricidad,
redondeadas a dos decimales.
    '''
    
    factor_electricidad = 0.164
    
    perdida_red = 1 - perdida_red
    # Calculo de emisiones
    emisiones_electricidad = (kwh / perdida_red) * factor_electricidad
    
    return round(emisiones_electricidad,2)

    

def calcular_penalizacion_carne (kg_carne: float, variedad: int) -> float:
    '''
    SUMMARY.

    Parameters
    ----------
    kg_carne : float
        DESCRIPTION.
    variedad : int
        DESCRIPTION.

    Returns
    -------
    float
        DESCRIPTION.
        penalización por mes por consumo de carne, dado que este alimento tiene un mayor
            impacto ambiental
que otros alimentos.
    '''
    # procesos matematicos
    kg_carne = kg_carne / (1 + kg_carne)
    
    variedad = 1 - (variedad / 10)
    
    penalizacion = round(kg_carne * variedad,2)
    
    return penalizacion


def calcular_emisiones_alimentacion (kg_carne: float, kg_totales: float, variedad: int)-> float:
    '''
    SUMMARY.

    Parameters
    ----------
    kg_carne : float
        DESCRIPTION.
    kg_totales : float
        DESCRIPTION.
    variedad : int
        DESCRIPTION.

    Returns
    -------
    float
        DESCRIPTION.
        emisiones mensuales de una persona por concepto de alimentación.

    '''
    # se llama a la funcion de penalizacion
    penalizacion = calcular_penalizacion_carne(kg_carne, variedad)
    
    #el elevado a la 1/2 es para sacar la raiz cuadrada
    penalizacion = 1 + (penalizacion**1/2)
    
    factor_alimentos = 2.5
    
    emision_alimentos = round(kg_totales * factor_alimentos * penalizacion,2)
    
    return emision_alimentos
    



def calcular_emisiones_totales(km_dia: float, factor_emision_km: float, kwh: float,\
                               perdida_red: float, kg_carne: float, kg_totales: float, variedad: int)->float:
    '''
    SUMMARY.

    Parameters
    ----------
    km_dia : float
        DESCRIPTION.
    factor_emision_km : float
        DESCRIPTION.
    kwh : float
        DESCRIPTION.
    perdida_red : float
        DESCRIPTION.
    kg_carne : float
        DESCRIPTION.
    kg_totales : float
        DESCRIPTION.
    variedad : int
        DESCRIPTION.

    Returns
    -------
    float
        DESCRIPTION.
         emisiones anuales de una persona en kilogramos de CO2.

    '''
    # se llaman a todas las funciones anteriores y se multiplican *12 para hacerlas por aaño, escepto
    # por transporte que seria *365
    emisiones_transporte_anual = calcular_emisiones_transporte(km_dia, factor_emision_km) * 365
    
    emisiones_electricidad_anual = calcular_emisiones_electricidad(kwh, perdida_red)* 12
    
    emisiones_alimentacion_anual = calcular_emisiones_alimentacion(kg_carne, kg_totales, variedad)* 12
    
    total_emisiones = emisiones_alimentacion_anual + emisiones_electricidad_anual + emisiones_transporte_anual
    
    
    return round(total_emisiones,2)


def calcular_arboles_necesarios(km_dia: float, factor_emision_km: float,\
                                kwh: float, perdida_red: float, kg_carne: float,\
                                    kg_totales: float, variedad: int) -> int:
    '''
    SUMMARY.

    Parameters
    ----------
    km_dia : float
        DESCRIPTION.
    factor_emision_km : float
        DESCRIPTION.
    kwh : float
        DESCRIPTION.
    perdida_red : float
        DESCRIPTION.
    kg_carne : float
        DESCRIPTION.
    kg_totales : float
        DESCRIPTION.
    variedad : int
        DESCRIPTION.

    Returns
    -------
    int
        DESCRIPTION.
        cuántos árboles son necesarios para compensar el
impacto de las emisiones anuales de una persona
    '''
    
    total_emisiones = calcular_emisiones_totales(km_dia, factor_emision_km, kwh,\
                                                 perdida_red, kg_carne, kg_totales, variedad)

    
    arbol_necesarios = int(total_emisiones/22)
    
    return arbol_necesarios
    
    